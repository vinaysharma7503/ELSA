# Bootstrap-Confirmation

[![Bower version](https://badge.fury.io/bo/bootstrap-confirmation2.svg)](http://badge.fury.io/bo/bootstrap-confirmation2)

Bootstrap plugin for on-place confirm boxes using Popover.


## Documentation

http://mistic100.github.io/Bootstrap-Confirmation


## Changes from original one

- Bootstrap 3 compatible
- Fix double event fires
- Automatic handle of links (without need of custom callback)
