<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanDisbursedBy extends Model
{
    protected $table = "loan_disbursed_by";
    public $timestamps=false;
}
