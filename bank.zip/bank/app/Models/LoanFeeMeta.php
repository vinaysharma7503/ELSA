<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LoanFeeMeta extends Model
{
    protected $table = "loan_fees_meta";

    public $timestamps = false;
}
