<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PayrollTemplate extends Model
{
    protected $table = "payroll_templates";
    public $timestamps = false;
}
